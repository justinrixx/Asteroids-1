/***********************************************************************
* Program:
*    Point Class Source File 
*    Brother Helfrich, CS165
* Author:
*    Nicholas Recht
* Summary: 
*    This file contains the member definitions for the Point Class
************************************************************************/

#include "point.h"
using namespace std;


