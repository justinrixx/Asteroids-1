# Networked Asteroids
This project is a team project done as part of a CS networking class. To get the game running, run `make server`, then `make client`. To start the server, execute `./server <port #> <# of players>`. To connect to the server from a client, run `./client <server hostname> <port #>`. The game will begin when all clients have connected.
